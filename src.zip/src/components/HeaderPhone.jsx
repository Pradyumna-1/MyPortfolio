import React from "react";
import { NavContent } from "./Header;
const HeaderPhone = () => {
  return (
    <div className={"navPhone"}>
      <NavContent />
    </div>
  );
};

export default HeaderPhone;
